package Program.GeoTrees;

public enum RelationType {
    PARENTOF,
    HUSBANDWIFEOF,
    CHILDOF
}