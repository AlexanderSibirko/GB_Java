package Program.Animals;

public interface HearCall {
    void hearCall(String words); // у всех житовных должна быть некая реакция на зов
}
