package Program.Item;

public interface ItemManager {
    boolean addItem(Item item);
    boolean removeItem(Item item);
}
