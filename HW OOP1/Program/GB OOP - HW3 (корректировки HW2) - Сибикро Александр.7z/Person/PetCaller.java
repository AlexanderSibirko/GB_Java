package Program.Person;

import Program.Animals.Pets;

public interface PetCaller {
    void callPet(Pets[] pets, String phrase);
}
